#ifndef _SHAPEPARAMINDEX_H
#define _SHAPEPARAMINDEX_H


enum ShapeParamIndex
{
    PARAM_RADIUS = 0,
    PARAM_WIDTH,
    PARAM_HEIGHT,
    PARAM_DIAGONAL,
    PARAM_DEPTH,
    PARAM_ANGLE,
    PARAM_DIAGONAL_2,
    PARAM_RADIUS_2,
    PARAM_SIDE_A,
    PARAM_SIDE_B,
    PARAM_SIDE_C
};
#endif
